package com.klef.fsad.exam;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ClientDemo {

    public static void main(String[] args) {

        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();

        Transaction tx = session.beginTransaction();

        Ticket t1 = new Ticket("Movie Ticket", "Booked");
        Ticket t2 = new Ticket("Bus Ticket", "Pending");

        session.save(t1);
        session.save(t2);

        tx.commit();
        System.out.println("Records Inserted!");

        session = factory.openSession();
        tx = session.beginTransaction();

        String hql = "update Ticket set name = ?1, status = ?2 where id = ?3";
        Query query = session.createQuery(hql);

        query.setParameter(1, "Flight Ticket");
        query.setParameter(2, "Confirmed");
        query.setParameter(3, 1);

        int result = query.executeUpdate();

        tx.commit();
        System.out.println("Rows Updated: " + result);

        session.close();
        factory.close();
    }
}
